
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, scrolledtext
import os
import subprocess
import sys
from dataclasses import dataclass, field
from typing import List, Optional, Union
from datetime import datetime
# OPERADORES

OPER_MAP = {
    'SUMA': '+',
    'RESTA': '-',
    'MULTIPLICACION': '*',
    'DIVISION': '/',
    'POTENCIA': '^',
    'RAIZ': 'r',
    'INVERSO': 'i',
    'MOD': '%'
}

@dataclass
class Token:
    tipo: str
    lexema: str
    fila: int
    columna: int

class ScannerLexico:
    """
     token  y  errores lexicos
    """
    PALABRAS_RESERVADAS = set(OPER_MAP.keys())
    ETIQUETAS = {'Operacion', 'Numero', 'P', 'R'}

    def __init__(self, texto: str):
        self.texto = texto
        self.posicion = 0
        self.fila = 1
        self.columna = 1
        self.tokens: List[Token] = []
        self.errores: List[dict] = []

    def peek(self, offset: int = 0) -> Optional[str]:
        pos = self.posicion + offset
        return self.texto[pos] if pos < len(self.texto) else None

    def advance(self) -> Optional[str]:
        if self.posicion >= len(self.texto):
            return None
        ch = self.texto[self.posicion]
        self.posicion += 1
        if ch == '\n':
            self.fila += 1
            self.columna = 1
        else:
            self.columna += 1
        return ch

    def es_digito(self, ch: Optional[str]) -> bool:
        return ch is not None and '0' <= ch <= '9'

    def es_letra(self, ch: Optional[str]) -> bool:
        return ch is not None and (('A' <= ch <= 'Z') or ('a' <= ch <= 'z'))

    def es_espacio(self, ch: Optional[str]) -> bool:
        return ch in (' ', '\t', '\n', '\r')

    def registrar_error(self, mensaje: str, fila: int, columna: int, lexema: str):
        """verifica un error en el formato que es """
        self.errores.append({
            "No": len(self.errores) + 1,
            "Lexema": lexema,
            "Tipo": "Error",
            "Columna": columna,
            "Fila": fila,
            "Mensaje": mensaje
        })

    def extraer_numero(self) -> Token:
        inicio_fila = self.fila
        inicio_columna = self.columna
        num = ""
        while self.es_digito(self.peek()):
            num += self.advance()
        if self.peek() == '.':
            num += self.advance()
            while self.es_digito(self.peek()):
                num += self.advance()
        return Token("NUMERO", num, inicio_fila, inicio_columna)

    def extraer_palabra_o_etiqueta(self) -> Token:
        inicio_fila = self.fila
        inicio_columna = self.columna
        palabra = ""
        while self.es_letra(self.peek()) or self.peek() == '_':
            palabra += self.advance()
        palabra_norm = palabra.upper()
        return Token("IDENTIFICADOR", palabra_norm, inicio_fila, inicio_columna)

    def extraer_etiqueta_abierta(self) -> Token:
        inicio_fila = self.fila
        inicio_columna = self.columna
        lex = ""
        # consume '<'
        lex += self.advance()
        nombre = ""
        while self.es_letra(self.peek()) or self.peek() == '_':
            nombre += self.advance()
        if not nombre:
            self.registrar_error("Etiqueta sin nombre", inicio_fila, inicio_columna, "<")
            # sincronizar hasta '>'
            while self.peek() and self.peek() != '>':
                self.advance()
            if self.peek() == '>':
                lex += self.advance()
            return Token("ETIQUETA_ABIERTA", lex, inicio_fila, inicio_columna)
        lex += nombre
        if self.peek() == '=':
            lex += self.advance()
            while self.es_espacio(self.peek()) and self.peek() != '\n':
                lex += self.advance()
            tipo_op = ""
            while self.es_letra(self.peek()) or self.peek() == '_':
                tipo_op += self.advance()
            tipo_op_norm = tipo_op.upper()
            if tipo_op_norm and tipo_op_norm not in self.PALABRAS_RESERVADAS:
                self.registrar_error(f"Tipo de operacion no valido: {tipo_op_norm}", self.fila, self.columna - len(tipo_op), tipo_op_norm)
            lex += tipo_op
        # consumir espacios hasta '>'
        while self.es_espacio(self.peek()) and self.peek() != '\n':
            lex += self.advance()
        if self.peek() == '>':
            lex += self.advance()
        else:
            self.registrar_error("Se esperaba '>' para cerrar etiqueta", self.fila, self.columna, self.peek() or "EOF")
        return Token("ETIQUETA_ABIERTA", lex, inicio_fila, inicio_columna)

    def extraer_etiqueta_cerrada(self) -> Token:
        inicio_fila = self.fila
        inicio_columna = self.columna
        lex = ""
        lex += self.advance()  # '<'
        if self.peek() != '/':
            self.registrar_error("Se esperaba '/' en etiqueta de cierre", self.fila, self.columna, self.peek() or "")
            return Token("ETIQUETA_CERRADA", lex, inicio_fila, inicio_columna)
        lex += self.advance()  # '/'
        nombre = ""
        while self.es_letra(self.peek()) or self.peek() == '_':
            nombre += self.advance()
        if nombre not in self.ETIQUETAS:
            self.registrar_error(f"Etiqueta de cierre no valida: {nombre}", inicio_fila, inicio_columna, f"</{nombre}")
        lex += nombre
        if self.peek() == '>':
            lex += self.advance()
        else:
            self.registrar_error("Se esperaba '>'", self.fila, self.columna, "")
        return Token("ETIQUETA_CERRADA", lex, inicio_fila, inicio_columna)

    def scanear(self) -> List[Token]:
        while self.posicion < len(self.texto):
            ch = self.peek()
            if self.es_espacio(ch):
                self.advance()
                continue
            if self.es_digito(ch):
                self.tokens.append(self.extraer_numero())
            elif ch == '<':
                if self.peek(1) == '/':
                    self.tokens.append(self.extraer_etiqueta_cerrada())
                else:
                    self.tokens.append(self.extraer_etiqueta_abierta())
            elif ch == '=':
                self.tokens.append(Token("IGUAL", self.advance(), self.fila, self.columna - 1))
            elif ch == '>':
                self.tokens.append(Token("MAYOR", self.advance(), self.fila, self.columna - 1))
            elif self.es_letra(ch) or ch == '_':
                self.tokens.append(self.extraer_palabra_o_etiqueta())
            else:
                # caracter invalido
                inval = self.advance()
                self.registrar_error("Caracter no reconocido", self.fila, self.columna - 1, inval)
                self.tokens.append(Token("ERROR", inval, self.fila, self.columna - 1))
        self.tokens.append(Token("EOF", "", self.fila, self.columna))
        return self.tokens

# NODOS   PARSER Y EVALUADOR el cual nos ayuda al la construccion del arbol


@dataclass
class NodoOperacion:
    tipo: str
    operandos: List[Union['NodoOperacion', float]] = field(default_factory=list)
    valido: bool = True

class Parser:
    """
    Parser que construye los nodos
    """
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.posicion = 0
        self.errores: List[str] = []

    def peek(self, offset: int = 0) -> Optional[Token]:
        pos = self.posicion + offset
        return self.tokens[pos] if pos < len(self.tokens) else None

    def advance(self) -> Optional[Token]:
        t = self.peek()
        self.posicion += 1
        return t

    def esperar(self, tipo: str) -> bool:
        t = self.peek()
        return bool(t and t.tipo == tipo)

    def consumir(self, tipo: str) -> Token:
        if not self.esperar(tipo):
            raise Exception(f"Se esperaba {tipo}, se encontro {self.peek().tipo if self.peek() else 'EOF'}")
        return self.advance()

    def extraer_tipo_operacion(self, lexema: str) -> str:
        if '=' not in lexema:
            return ""
        try:
            partes = lexema.split('=', 1)
            if len(partes) != 2:
                return ""
            tipo = partes[1].replace('>', '').strip().upper()
            return tipo
        except Exception:
            return ""

    def parsear(self) -> List[Union[NodoOperacion, float]]:
        operaciones = []
        while self.posicion < len(self.tokens):
            t = self.peek()
            if t is None or t.tipo == "EOF":
                break
            if t.tipo == "ETIQUETA_ABIERTA":
                lex = t.lexema
                if "Operacion" in lex or "OPERACION" in lex:
                    operaciones.append(self.parsear_operacion(nivel=0))
                elif "Numero" in lex or "NUMERO" in lex:
                    operaciones.append(self.parsear_numero())
                else:
                    self.advance()
            else:
                self.advance()
        if len(operaciones) == 1:
            return operaciones[0]
        elif len(operaciones) > 1:
            return operaciones
        else:
            raise Exception("No se encontraron operaciones para analizar")

    def parsear_operacion(self, nivel: int = 0) -> NodoOperacion:
        etiqueta = self.consumir("ETIQUETA_ABIERTA")
        tipo_op = self.extraer_tipo_operacion(etiqueta.lexema).upper()
        nodo: NodoOperacion
        if not tipo_op or tipo_op not in OPER_MAP:
            nodo = NodoOperacion('?', [], valido=False)
        else:
            nodo = NodoOperacion(OPER_MAP[tipo_op], [], valido=True)

        while self.posicion < len(self.tokens):
            t = self.peek()
            if t is None:
                nodo.valido = False
                raise Exception("Token EOF inesperado")
            if t.tipo == "ETIQUETA_CERRADA" and ("Operacion" in t.lexema or "OPERACION" in t.lexema):
                self.consumir("ETIQUETA_CERRADA")
                break
            elif t.tipo == "ETIQUETA_ABIERTA" and ("<Numero>" in t.lexema or "<NUMERO>" in t.lexema):
                try:
                    num = self.parsear_numero()
                    nodo.operandos.append(num)
                except Exception:
                    nodo.valido = False
            elif t.tipo == "ETIQUETA_ABIERTA" and ("<Operacion" in t.lexema or "<OPERACION" in t.lexema):
                try:
                    hijo = self.parsear_operacion(nivel + 1)
                    nodo.operandos.append(hijo)
                    if isinstance(hijo, NodoOperacion) and not hijo.valido:
                        nodo.valido = False
                except Exception:
                    nodo.valido = False
                    try:
                        self.advance()
                    except:
                        pass
            elif t.tipo == "ETIQUETA_ABIERTA" and ("<P>" in t.lexema or "<P" in t.lexema):
                try:
                    p = self.parsear_parametro_p()
                    nodo.operandos.insert(0, p)
                except Exception:
                    nodo.valido = False
            elif t.tipo == "ETIQUETA_ABIERTA" and ("<R>" in t.lexema or "<R" in t.lexema):
                try:
                    r = self.parsear_parametro_r()
                    nodo.operandos.insert(0, r)
                except Exception:
                    nodo.valido = False
            else:
                self.advance()

        if not nodo.operandos:
            nodo.valido = False

        return nodo

    def parsear_numero(self) -> float:
        self.consumir("ETIQUETA_ABIERTA")
        valor = 0.0
        if self.esperar("NUMERO"):
            tok = self.advance()
            try:
                valor = float(tok.lexema)
            except Exception:
                raise Exception(f"Valor numerico invalido: {tok.lexema}")
        self.consumir("ETIQUETA_CERRADA")
        return valor

    def parsear_parametro_p(self) -> float:
        self.consumir("ETIQUETA_ABIERTA")
        valor = 0.0
        if self.esperar("NUMERO"):
            valor = float(self.advance().lexema)
        self.consumir("ETIQUETA_CERRADA")
        return valor

    def parsear_parametro_r(self) -> float:
        self.consumir("ETIQUETA_ABIERTA")
        valor = 0.0
        if self.esperar("NUMERO"):
            valor = float(self.advance().lexema)
        self.consumir("ETIQUETA_CERRADA")
        return valor

class Evaluador:
    def __init__(self):
        pass

    def evaluar(self, nodo: Union[NodoOperacion, float, List]) -> Union[float, List[float]]:
        if isinstance(nodo, list):
            res = []
            for op in nodo:
                res.append(self.evaluar(op))
            return res
        if isinstance(nodo, (int, float)):
            return float(nodo)
        if isinstance(nodo, NodoOperacion):
            if not nodo.valido:
                raise Exception("Operacion invalida, verificar ")
            if nodo.tipo == '+':
                return self.suma(nodo.operandos)
            if nodo.tipo == '-':
                return self.resta(nodo.operandos)
            if nodo.tipo == '*':
                return self.multiplicacion(nodo.operandos)
            if nodo.tipo == '/':
                return self.division(nodo.operandos)
            if nodo.tipo == '^':
                return self.potencia(nodo.operandos)
            if nodo.tipo == 'r':
                return self.raiz(nodo.operandos)
            if nodo.tipo == 'i':
                return self.inverso(nodo.operandos)
            if nodo.tipo == '%':
                return self.modulo(nodo.operandos)
        raise Exception(f"Tipo de nodo desconocido: {type(nodo)}")

    def suma(self, operandos: List) -> float:
        total = 0.0
        for op in operandos:
            total += self.evaluar(op)
        return total

    def resta(self, operandos: List) -> float:
        if not operandos:
            return 0.0
        total = self.evaluar(operandos[0])
        for op in operandos[1:]:
            total -= self.evaluar(op)
        return total

    def multiplicacion(self, operandos: List) -> float:
        total = 1.0
        for op in operandos:
            total *= self.evaluar(op)
        return total

    def division(self, operandos: List) -> float:
        if not operandos:
            return 0.0
        total = self.evaluar(operandos[0])
        for op in operandos[1:]:
            div = self.evaluar(op)
            if div == 0:
                raise Exception("Division por cero")
            total /= div
        return total

    def potencia(self, operandos: List) -> float:
        if len(operandos) < 2:
            raise Exception("POTENCIA requiere 2 operandos")
        ex = self.evaluar(operandos[0])
        base = self.evaluar(operandos[1])
        return base ** ex

    def raiz(self, operandos: List) -> float:
        if len(operandos) < 2:
            raise Exception("RAIZ requiere 2 operandos")
        indice = self.evaluar(operandos[0])
        rad = self.evaluar(operandos[1])
        if indice == 0:
            raise Exception("Indice de raiz no puede ser cero")
        if rad < 0 and int(indice) % 2 == 0:
            raise Exception("Raiz par de numero negativo")
        return rad ** (1 / indice)

    def inverso(self, operandos: List) -> float:
        if not operandos:
            raise Exception("INVERSO requiere 1 operando")
        val = self.evaluar(operandos[0])
        if val == 0:
            raise Exception("Inverso de cero")
        return 1.0 / val

    def modulo(self, operandos: List) -> float:
        if len(operandos) < 2:
            raise Exception("MOD requiere 2 operandos")
        res = int(self.evaluar(operandos[0]))
        for op in operandos[1:]:
            d = int(self.evaluar(op))
            if d == 0:
                raise Exception("MOD: divisor cero")
            res = res % d
        return float(res)

    def generar_expresion(self, nodo: Union[NodoOperacion, float, List]) -> str:
        if isinstance(nodo, list):
            exprs = []
            for i, op in enumerate(nodo, 1):
                exprs.append(f"{i}. {self.generar_expresion(op)}")
            return "\n".join(exprs)
        if isinstance(nodo, (int, float)):
            if isinstance(nodo, float) and nodo.is_integer():
                return str(int(nodo))
            return str(nodo)
        if isinstance(nodo, NodoOperacion):
            operandos_str = [self.generar_expresion(op) for op in nodo.operandos]
            op = nodo.tipo
            if op == '+':
                return "(" + "+".join(operandos_str) + ")"
            if op == '-':
                return "(" + "-".join(operandos_str) + ")"
            if op == '*':
                return "(" + "*".join(operandos_str) + ")"
            if op == '/':
                return "(" + "/".join(operandos_str) + ")"
            if op == '^':
                if len(operandos_str) >= 2:
                    return f"({operandos_str[1]}^{operandos_str[0]})"
                return "(potencia_error)"
            if op == 'r':
                if len(operandos_str) >= 2:
                    return f"(√[{operandos_str[0]}]{operandos_str[1]})"
                return "(raiz_error)"
            if op == 'i':
                if operandos_str:
                    return f"(1/{operandos_str[0]})"
                return "(inverso_error)"
            if op == '%':
                return "(" + "%".join(operandos_str) + ")"
        return str(nodo)

# graficos tkinter

class AnalizadorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Analizador de Operaciones Aritmeticas")
        self.root.geometry("1400x900")
        self.root.config(bg="#2c3e50")

        self.archivo_actual = None
        self.arbol_actual = None
        self.evaluador_actual = None
        self.tokens_actual: List[Token] = []
        self.scanner_actual: Optional[ScannerLexico] = None
        self.ultimos_errores_operaciones: List[tuple] = []

        self.crear_widgets()
        self.ruta_manual_usuario = os.path.join(os.path.dirname(__file__), "ManualUsuario.pdf")
        self.ruta_manual_tecnico = os.path.join(os.path.dirname(__file__), "ManualTecnico.pdf")

    def crear_widgets(self):
        self.configurar_estilos()
        
        main_frame = tk.Frame(self.root, bg="#2c3e50")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)

        header_frame = tk.Frame(main_frame, bg="#34495e", relief=tk.RAISED, bd=2)
        header_frame.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(header_frame, text="ANALIZADOR DE OPERACIONES ARITMETICAS", 
                font=("Arial", 16, "bold"), bg="#34495e", fg="white", pady=10).pack()

        control_frame = tk.Frame(main_frame, bg="#34495e", relief=tk.RAISED, bd=1)
        control_frame.pack(fill=tk.X, pady=(0, 15))

        file_frame = tk.Frame(control_frame, bg="#34495e")
        file_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Button(file_frame, text="Abrir Archivo", command=self.abrir_archivo, 
                 width=15, bg="red", fg="white", font=("Arial", 9, "bold")).pack(side=tk.LEFT, padx=2)
        tk.Button(file_frame, text=" Guardar", command=self.guardar_archivo, 
                 width=12, bg="red", fg="white", font=("Arial", 9)).pack(side=tk.LEFT, padx=2)
        tk.Button(file_frame, text=" Guardar Como", command=self.guardar_como, 
                 width=12, bg="red", fg="white", font=("Arial", 9)).pack(side=tk.LEFT, padx=2)
        tk.Button(file_frame, text=" Analizar", command=self.analizar, 
                 width=12, bg="red", fg="white", font=("Arial", 9, "bold")).pack(side=tk.LEFT, padx=2)

        export_frame = tk.Frame(control_frame, bg="#34495e")
        export_frame.pack(fill=tk.X, padx=10, pady=5)
        
        tk.Button(export_frame, text=" Exportar HTML", command=self.exportar_html, 
                 width=15, bg="red", fg="white", font=("Arial", 9)).pack(side=tk.LEFT, padx=2)
        tk.Button(export_frame, text=" Manual Usuario", command=self.mostrar_manual_usuario, 
                 width=15, bg="red", fg="white", font=("Arial", 9)).pack(side=tk.LEFT, padx=2)
        tk.Button(export_frame, text=" Manual Tecnico", command=self.mostrar_manual_tecnico, 
                 width=15, bg="red", fg="white", font=("Arial", 9)).pack(side=tk.LEFT, padx=2)
        tk.Button(export_frame, text="Acerca de", command=self.acerca_de, 
                 width=12, bg="red", fg="white", font=("Arial", 9)).pack(side=tk.LEFT, padx=2)

        content_frame = tk.Frame(main_frame, bg="#2c3e50")
        content_frame.pack(fill=tk.BOTH, expand=True)

        left_column = tk.Frame(content_frame, bg="#2c3e50")
        left_column.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

        right_panel = tk.Frame(content_frame, bg="#34495e", width=150, height=500)
        right_panel.pack(side=tk.RIGHT, fill=tk.Y)
        right_panel.pack_propagate(False) 



        try:
            self.imagen = tk.PhotoImage(file="logotipo.png")
            tk.Label(right_panel, image=self.imagen, bg="#34495e").pack(pady=20)
        except:
            tk.Label(right_panel, text="Tu Imagen", bg="#34495e", fg="white").pack(pady=20)
        
              


        code_frame = tk.LabelFrame(left_column, text=" EDITOR DE CODIGO FUENTE ", 
                                  font=("Arial", 10, "bold"), bg="#34495e", fg="white", 
                                  relief=tk.RAISED, bd=2)
        code_frame.pack(fill=tk.BOTH, expand=True)

        self.entrada_text = scrolledtext.ScrolledText(code_frame, height=20, width=60, 
                                                     font=("Consolas", 11), bg="#1e272e", fg="#ecf0f1",
                                                     insertbackground="white")
        self.entrada_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        right_column = tk.Frame(content_frame, bg="#2c3e50")
        right_column.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        self.notebook = ttk.Notebook(right_column)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        style = ttk.Style()
        style.configure("TNotebook.Tab", font=("Arial", 9, "bold"))

        tab_tokens_frame = ttk.Frame(self.notebook)
        self.notebook.add(tab_tokens_frame, text=" TOKENS")
        
        self.tab_tokens = scrolledtext.ScrolledText(tab_tokens_frame, height=15, 
                                                   font=("Courier", 9), bg="#1e272e", fg="#ecf0f1")
        self.tab_tokens.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        tab_tree_frame = ttk.Frame(self.notebook)
        self.notebook.add(tab_tree_frame, text="ARBOL")
        
        tree_controls = tk.Frame(tab_tree_frame, bg="#34495e")
        tree_controls.pack(fill=tk.X, padx=5, pady=5)
        
        self.label_arbol_info = tk.Label(tree_controls, text="Arbol de operacion unica", 
                                        font=("Arial", 10, "bold"), bg="#34495e", fg="white")
        self.label_arbol_info.pack(side=tk.LEFT)
        
        
        tk.Button(tree_controls, text="Siguiente ", command=self.siguiente_arbol, 
                 width=12, bg="green", fg="white").pack(side=tk.RIGHT, padx=2)
        tk.Button(tree_controls, text="Anterior", command=self.anterior_arbol,
                                   width=12, bg="green", fg="white").pack(side=tk.RIGHT, padx=2)


        self.canvas_arbol = tk.Canvas(tab_tree_frame, bg="white", highlightthickness=1, 
                                     highlightbackground="#7f8c8d")
        self.canvas_arbol.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.arbol_index_actual = 0

        tab_expr_frame = ttk.Frame(self.notebook)
        
        self.tab_expresion = scrolledtext.ScrolledText(tab_expr_frame, height=15,
                                                      font=("Courier", 10), bg="#1e272e", fg="#ecf0f1")
        self.tab_expresion.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

       

        status_frame = tk.Frame(main_frame, bg="#34495e", relief=tk.SUNKEN, bd=1)
        status_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.status_label = tk.Label(status_frame, text="Listo para analizar", 
                                    font=("Arial", 9), bg="#34495e", fg="white", anchor=tk.W)
        self.status_label.pack(fill=tk.X, padx=10, pady=5)

    def configurar_estilos(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        style.configure("TNotebook", background="#2c3e50")
        style.configure("TNotebook.Tab", 
                       background="#34495e",
                       foreground="white",
                       padding=[10, 5],
                       font=("Arial", 9, "bold"))
        style.map("TNotebook.Tab", 
                 background=[("selected", "#2980b9")],
                 foreground=[("selected", "white")])

    def abrir_archivo(self):
        archivo = filedialog.askopenfilename(filetypes=[("Texto", "*.txt"), ("XML", "*.xml"), ("Todos", "*.*")])
        if archivo:
            with open(archivo, 'r', encoding='utf-8') as f:
                contenido = f.read()
            self.entrada_text.delete(1.0, tk.END)
            self.entrada_text.insert(1.0, contenido)
            self.archivo_actual = archivo
            self.root.title(f"Analizador - {os.path.basename(archivo)}")
            self.status_label.config(text=f"Archivo cargado: {os.path.basename(archivo)}")

    def guardar_archivo(self):
        if not self.archivo_actual:
            self.guardar_como()
            return
        contenido = self.entrada_text.get(1.0, tk.END)
        with open(self.archivo_actual, 'w', encoding='utf-8') as f:
            f.write(contenido)
        messagebox.showinfo("Exito", "Archivo guardado ")
        self.status_label.config(text="Archivo guardado ")

    def guardar_como(self):
        archivo = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Texto", "*.txt"), ("XML", "*.xml"), ("Todos", "*.*")])
        if archivo:
            contenido = self.entrada_text.get(1.0, tk.END)
            with open(archivo, 'w', encoding='utf-8') as f:
                f.write(contenido)
            self.archivo_actual = archivo
            self.root.title(f"Analizador - {os.path.basename(archivo)}")
            messagebox.showinfo("Exito", "Archivo guardado ")
            self.status_label.config(text=f"Archivo guardado como: {os.path.basename(archivo)}")

    def _extraer_subtokens_operacion(self, tokens: List[Token], start_idx: int) -> List[Token]:
        subtokens: List[Token] = []
        i = start_idx
        profundidad = 0
        last_token = None
        while i < len(tokens):
            t = tokens[i]
            subtokens.append(t)
            last_token = t
            if t.tipo == "ETIQUETA_ABIERTA" and ("Operacion" in t.lexema or "OPERACION" in t.lexema):
                profundidad += 1
            elif t.tipo == "ETIQUETA_CERRADA" and ("Operacion" in t.lexema or "OPERACION" in t.lexema):
                profundidad -= 1
                if profundidad == 0:
                    break
            i += 1
        if last_token:
            subtokens.append(Token("EOF", "", last_token.fila, last_token.columna))
        else:
            subtokens.append(Token("EOF", "", 0, 0))
        return subtokens

    def analizar(self):
        texto = self.entrada_text.get(1.0, tk.END)
        try:
            self.arbol_index_actual = 0
            self.ultimos_errores_operaciones = []
            self.status_label.config(text="Analizando codigo")

            self.scanner_actual = ScannerLexico(texto)
            self.tokens_actual = self.scanner_actual.scanear()

            self.tab_tokens.tag_configure("etiqueta", foreground="#3498db", font=("Courier", 9, "bold"))
            self.tab_tokens.tag_configure("numero", foreground="#27ae60", font=("Courier", 9))
            self.tab_tokens.tag_configure("error", foreground="#e74c3c", font=("Courier", 9, "bold"))
            self.tab_tokens.tag_configure("normal", foreground="#ecf0f1", font=("Courier", 9))
            self.tab_tokens.tag_configure("header", foreground="#9b59b6", font=("Courier", 10, "bold"))

            self.tab_tokens.delete(1.0, tk.END)
            
            self.tab_tokens.insert(tk.END, "┌" + "─" * 15 + "┬" + "─" * 25 + "┬" + "─" * 12 + "┐\n", "header")
            self.tab_tokens.insert(tk.END, f"│ {'TIPO':13} │ {'LEXEMA':23} │ {'UBICACION':10} │\n", "header")
            self.tab_tokens.insert(tk.END, "├" + "─" * 15 + "┼" + "─" * 25 + "┼" + "─" * 12 + "┤\n", "header")

            for token in self.tokens_actual:
                if token.tipo != "EOF":
                    tag = "normal"
                    if "ETIQUETA" in token.tipo:
                        tag = "etiqueta"
                    elif "NUMERO" in token.tipo:
                        tag = "numero"
                    elif "ERROR" in token.tipo:
                        tag = "error"
                    
                    ubicacion = f"F{token.fila:02}C{token.columna:02}"
                    linea = f"│ {token.tipo:13} │ {token.lexema:23} │ {ubicacion:10} │\n"
                    self.tab_tokens.insert(tk.END, linea, tag)

            self.tab_tokens.insert(tk.END, "└" + "─" * 15 + "┴" + "─" * 25 + "┴" + "─" * 12 + "┘\n", "header")

            operaciones_brutas = None
            try:
                parser = Parser(self.tokens_actual)
                operaciones_brutas = parser.parsear()
            except Exception:
                operaciones_brutas = None

            operaciones_validas = []
            errores_operaciones = []

            if operaciones_brutas is not None:
                if isinstance(operaciones_brutas, list):
                    lista_raices = operaciones_brutas
                else:
                    lista_raices = [operaciones_brutas]
                evaluador = Evaluador()
                for idx, raiz in enumerate(lista_raices, 1):
                    if isinstance(raiz, NodoOperacion) and not raiz.valido:
                        errores_operaciones.append((idx, "Operacion invalida"))
                        continue
                    try:
                        _ = evaluador.evaluar(raiz)
                        operaciones_validas.append(raiz)
                    except Exception as e_eval:
                        errores_operaciones.append((idx, str(e_eval)))
            else:
                indices = []
                for i, tok in enumerate(self.tokens_actual):
                    if tok.tipo == "ETIQUETA_ABIERTA" and ("Operacion" in tok.lexema or "OPERACION" in tok.lexema):
                        indices.append(i)
                evaluador = Evaluador()
                contador = 0
                for si in indices:
                    contador += 1
                    try:
                        subtoks = self._extraer_subtokens_operacion(self.tokens_actual, si)
                        parser_sub = Parser(subtoks)
                        nodo = parser_sub.parsear()
                        if isinstance(nodo, NodoOperacion) and not nodo.valido:
                            errores_operaciones.append((contador, "Operacion invalida"))
                            continue
                        try:
                            _ = evaluador.evaluar(nodo)
                            operaciones_validas.append(nodo)
                        except Exception as e_eval:
                            errores_operaciones.append((contador, str(e_eval)))
                    except Exception as e_sub:
                        errores_operaciones.append((contador, str(e_sub)))

            if not operaciones_validas:
                self.arbol_actual = None
            elif len(operaciones_validas) == 1:
                self.arbol_actual = operaciones_validas[0]
            else:
                self.arbol_actual = operaciones_validas

            self.ultimos_errores_operaciones = errores_operaciones

            self.evaluador_actual = Evaluador()
            

          

            self.mostrar_arbol_visual()

    

            if self.ultimos_errores_operaciones:
                mensaje = "Analisis completado con errores:\n"
                for idx, msg in self.ultimos_errores_operaciones:
                    mensaje += f"- Operacion {idx}: {msg}\n"
                if operaciones_validas:
                    mensaje += "Las demas operaciones se procesaron bien."
                else:
                    mensaje += "No se procesaron operaciones correctamente."
                messagebox.showwarning("Analisis con errores", mensaje)
                self.status_label.config(text="Analisis completado tiene errores")
            else:
                total_ops = len(operaciones_validas) if operaciones_validas else 0
                messagebox.showinfo("Exito", f"Analisis completado exitosamente\n\nOperaciones analizadas excelente: {total_ops}")
                self.status_label.config(text=f"Analisis exitoso - {total_ops} operaciones procesadas")

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.tree_errores.delete(*self.tree_errores.get_children())
            self.tree_errores.insert('', tk.END, values=(1, "", "Error de Parsing", "-", "-"))
            self.tab_expresion.delete(1.0, tk.END)
            self.canvas_arbol.delete("all")
            messagebox.showerror("Error", f"Error en el analisis:\n{str(e)}")
            self.status_label.config(text="Error en el analisis")

    def generar_arbol_canvas(self, nodo: Union[NodoOperacion, float], x: float = 250, y: float = 30,
                            offset: float = 100, canvas = None) -> float:
        if canvas is None:
            return x
        if isinstance(nodo, (int, float)):
            canvas.create_oval(x-35, y-20, x+35, y+20, fill="blue", outline="black", width=2)
            canvas.create_text(x, y, text=f"{nodo:.2f}" if isinstance(nodo, float) else str(nodo),
                               font=("Arial", 9))
            return x
        if isinstance(nodo, NodoOperacion):
            num_hijos = len(nodo.operandos) if nodo.operandos else 0
            if num_hijos == 0:
                rect_color = "red" if not nodo.valido else "black"
                canvas.create_oval(x-50, y-25, x+50, y+25, fill="blue", outline=rect_color, width=2)
                canvas.create_text(x, y, text=nodo.tipo if nodo.tipo else "?", font=("Arial", 9, "bold"), width=90)
            else:
                total_width = num_hijos * offset
                inicio_x = x - total_width // 2
                posiciones = []
                for i, operando in enumerate(nodo.operandos):
                    hijo_x = inicio_x + i * offset + offset // 2
                    canvas.create_line(x, y + 30, hijo_x, y + 70, fill="black", width=1)
                    posiciones.append(hijo_x)
                rect_color = "red" if not nodo.valido else "black"
                canvas.create_oval(x-50, y-25, x+50, y+25, fill="blue", outline=rect_color, width=2)
                canvas.create_text(x, y, text=nodo.tipo if nodo.tipo else "?", font=("Arial", 11, "bold"), width=90)
                for i, operando in enumerate(nodo.operandos):
                    new_offset = max(50, int(offset // 1.5))
                    self.generar_arbol_canvas(operando, posiciones[i], y + 100, new_offset, canvas)
            return x
        return x

    def anterior_arbol(self):
        if isinstance(self.arbol_actual, list):
            if self.arbol_index_actual > 0:
                self.arbol_index_actual -= 1
                self.mostrar_arbol_visual()

    def siguiente_arbol(self):
        if isinstance(self.arbol_actual, list):
            if self.arbol_index_actual < len(self.arbol_actual) - 1:
                self.arbol_index_actual += 1
                self.mostrar_arbol_visual()

    def calcular_altura_arbol(self, nodo: Union[NodoOperacion, float]) -> int:
        if isinstance(nodo, (int, float)):
            return 1
        if isinstance(nodo, NodoOperacion):
            if not nodo.operandos:
                return 1
            max_altura = max(self.calcular_altura_arbol(op) for op in nodo.operandos)
            return max_altura + 1
        return 1

    def mostrar_arbol_visual(self):
        try:
            self.canvas_arbol.delete("all")
            arbol = self.arbol_actual
            titulo = ""
            if isinstance(self.arbol_actual, list):
                if len(self.arbol_actual) > 0:
                    if self.arbol_index_actual >= len(self.arbol_actual):
                        self.arbol_index_actual = len(self.arbol_actual) - 1
                    if self.arbol_index_actual < 0:
                        self.arbol_index_actual = 0
                    arbol = self.arbol_actual[self.arbol_index_actual]
                    num_act = self.arbol_index_actual + 1
                    total_ops = len(self.arbol_actual)
                    titulo = f"Mostrando operacion {num_act} de {total_ops}"
                    self.label_arbol_info.config(text=titulo)
            else:
                self.label_arbol_info.config(text="Arbol de operacion ")
            if arbol is None:
                return
            altura = self.calcular_altura_arbol(arbol) * 100 + 50
            self.canvas_arbol.config(scrollregion=(0, 0, 800, max(altura, 400)))
            self.generar_arbol_canvas(arbol, y=50, canvas=self.canvas_arbol)
        except Exception as e:
            self.canvas_arbol.delete("all")
            self.canvas_arbol.create_text(250, 200, text=f"Error al generar arbol:\n{str(e)}", fill="red", font=("Arial", 10))

    # ----------------------- EXPORTAR HTML SIMPLIFICADO -----------------------
    def exportar_html(self):
        if self.arbol_actual is None and not (self.scanner_actual and self.scanner_actual.errores):
            messagebox.showwarning("No hay resultados. Primero verifica el codigo.")
            return
        carpeta = filedialog.askdirectory(title="Seleccione la carpeta donde guardar los archivos HTML")
        if not carpeta:
            return
        try:
            # 1. ARCHIVO DE RESULTADOS
            if self.arbol_actual is None:
                resultados_rows = "<tr><td colspan='3' style='text-align:center; color:red;'>No hay resultados validos</td></tr>\n"
                total_ops = 0
            else:
                expresion_full = self.evaluador_actual.generar_expresion(self.arbol_actual)
                resultado_full = self.evaluador_actual.evaluar(self.arbol_actual)
                resultados_rows = ""
                if isinstance(resultado_full, list):
                    lineas = expresion_full.split('\n')
                    for idx, (linea, res) in enumerate(zip(lineas, resultado_full), 1):
                        expr_pura = linea.split('. ', 1)[1] if '. ' in linea else linea
                        resultados_rows += f"<tr><td>{idx}</td><td>{expr_pura}</td><td>{res:.3f}</td></tr>\n"
                else:
                    resultados_rows += f"<tr><td>1</td><td>{expresion_full}</td><td>{resultado_full:.3f}</td></tr>\n"
                total_ops = len(resultado_full) if isinstance(resultado_full, list) else 1

            resultados_html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Resultados - Operaciones</title>
    <style>
        body {{ font-family: Arial, sans-serif; padding: 20px; background: #f0f8ff; }}
        .container {{ background: white; padding: 25px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); max-width: 900px; margin: 0 auto; }}
        h1 {{ color: #2c3e50; text-align: center; border-bottom: 3px solid #3498db; padding-bottom: 15px; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 14px; }}
        th {{ background: #3498db; color: white; padding: 12px; text-align: center; font-weight: bold; }}
        td {{ padding: 10px; border: 1px solid #ddd; text-align: center; }}
        tr:nth-child(even) {{ background: #f8f9fa; }}
        tr:hover {{ background: #e3f2fd; }}
        .header {{ background: #34495e; color: white; padding: 15px; border-radius: 8px; margin-bottom: 20px; }}
        .success {{ color: #27ae60; font-weight: bold; }}
        .error {{ color: #e74c3c; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1> REPORTE DE RESULTADOS</h1>
            <p style="text-align: center; margin: 5px 0;">Analizador de Operaciones Aritmeticas</p>
        </div>
        
        <div style="background: #e8f5e8; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
            <h3 style="margin: 0; color: #27ae60;">✓ Resumen del Analisis</h3>
            <p style="margin: 5px 0;">Total de operaciones procesadas: <strong>{total_ops}</strong></p>
            <p style="margin: 5px 0;">Fecha de generacion: <strong>{datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</strong></p>
        </div>

        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Expresion</th>
                    <th>Resultado</th>
                </tr>
            </thead>
            <tbody>
                {resultados_rows}
            </tbody>
        </table>
        
        <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
            <p style="margin: 0; text-align: center; color: #7f8c8d;">
                Generado automaticamente por el Analizador de Operaciones Aritmeticas
            </p>
        </div>
    </div>
</body>
</html>"""
            resultados_path = os.path.join(carpeta, "Resultados.html")
            with open(resultados_path, 'w', encoding='utf-8') as f:
                f.write(resultados_html)

            # 2. ARCHIVO DE ERRORES
            errores_rows_html = ""
            total_errores = 0
            
            # errores lexicos
            if self.scanner_actual and self.scanner_actual.errores:
                for err in self.scanner_actual.errores:
                    total_errores += 1
                    errores_rows_html += f"""
                    <tr>
                        <td>{err.get('No','')}</td>
                        <td>{err.get('Lexema','')}</td>
                        <td>{err.get('Tipo','Error')}</td>
                        <td>{err.get('Columna','-')}</td>
                        <td>{err.get('Fila','-')}</td>
                    </tr>"""
            
            # errores de operacion
            start_num = len(self.scanner_actual.errores) if (self.scanner_actual and self.scanner_actual.errores) else 0
            if self.ultimos_errores_operaciones:
                for i, (idx, msg) in enumerate(self.ultimos_errores_operaciones, 1):
                    total_errores += 1
                    errores_rows_html += f"""
                    <tr>
                        <td>{start_num + i}</td>
                        <td>Operacion {idx}</td>
                        <td>Error</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>"""
            
            if not errores_rows_html:
                errores_rows_html = """
                    <tr>
                        <td colspan="5" style="text-align:center; color:#27ae60; font-weight:bold;">
                             No se encontraron errores en el analisis
                        </td>
                    </tr>"""

            errores_html = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Errores - Analisis</title>
    <style>
        body {{ font-family: Arial, sans-serif; padding: 20px; background: #fff5f5; }}
        .container {{ background: white; padding: 25px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); max-width: 1000px; margin: 0 auto; }}
        h1 {{ color: #2c3e50; text-align: center; border-bottom: 3px solid #e74c3c; padding-bottom: 15px; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 14px; }}
        th {{ background: #e74c3c; color: white; padding: 12px; text-align: center; font-weight: bold; }}
        td {{ padding: 10px; border: 1px solid #ddd; text-align: center; }}
        tr:nth-child(even) {{ background: #fdf2f2; }}
        tr:hover {{ background: #ffeaea; }}
        .header {{ background: #c0392b; color: white; padding: 15px; border-radius: 8px; margin-bottom: 20px; }}
        .summary {{ background: #ffebee; padding: 15px; border-radius: 8px; margin-bottom: 20px; }}
        .success {{ color: #27ae60; font-weight: bold; }}
        .error {{ color: #e74c3c; font-weight: bold; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1> REPORTE DE ERRORES</h1>
            <p style="text-align: center; margin: 5px 0;">Analizador de Operaciones Aritmeticas</p>
        </div>
        
        <div class="summary">
            <h3 style="margin: 0; color: #c0392b;"> Resumen de Errores</h3>
            <p style="margin: 5px 0;">Total de errores encontrados: <strong>{total_errores}</strong></p>
            <p style="margin: 5px 0;">Fecha de generacion: <strong>{datetime.now().strftime('%d/%m/%Y %H:%M:%S')}</strong></p>
        </div>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Lexema</th>
                    <th>Tipo</th>
                    <th>COLUMNA</th>
                    <th>FILA</th>
                </tr>
            </thead>
            <tbody>
                {errores_rows_html}
            </tbody>
        </table>
        
        <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
            <p style="margin: 0; text-align: center; color: #7f8c8d;">
                Generado automaticamente por el Analizador de Operaciones Aritmeticas
            </p>
        </div>
    </div>
</body>
</html>"""
            errores_path = os.path.join(carpeta, "Errores.html")
            with open(errores_path, 'w', encoding='utf-8') as f:
                f.write(errores_html)

            messagebox.showinfo("Exito", 
                f" Archivos HTML :\n\n"
                f" Resultados.html\n"
                f" Errores.html\n\n"
                f"Guardados en: {carpeta}")
            self.status_label.config(text="2 archivos HTML exportados correctamente")

        except Exception as e:
            messagebox.showerror("Error", f"Error al exportar HTML:\n{str(e)}")
            self.status_label.config(text="Error al exportar HTML")

    def mostrar_manual_usuario(self):
        if os.path.exists(self.ruta_manual_usuario):
            try:
                if os.name == 'nt':
                    os.startfile(self.ruta_manual_usuario)
                else:
                    opener = "open" if sys.platform == "darwin" else "xdg-open"
                    subprocess.Popen([opener, self.ruta_manual_usuario])
                self.status_label.config(text="Manual de Usuario abierto")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo abrir el Manual de Usuario:\n{str(e)}")
        else:
            messagebox.showerror("Error", f"No se encontro el archivo:\n{self.ruta_manual_usuario}")

    def mostrar_manual_tecnico(self):
        if os.path.exists(self.ruta_manual_tecnico):
            try:
                if os.name == 'nt':
                    os.startfile(self.ruta_manual_tecnico)
                else:
                    opener = "open" if sys.platform == "darwin" else "xdg-open"
                    subprocess.Popen([opener, self.ruta_manual_tecnico])
                self.status_label.config(text="Manual Tecnico abierto")
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo abrir el Manual Tecnico:\n{str(e)}")
        else:
            messagebox.showerror("Error", f"No se encontro\n{self.ruta_manual_tecnico}")

    def acerca_de(self):
        messagebox.showinfo("Acerca de",
            "Analizador de Operaciones Aritmeticas\n\n"
            "Version:1.2\n"
            "Fase 2  \n\n"
            " QUE HACE ESTE PROGRAMA?:\n"
            " Analiza Lexicamente\n"
            " Analiza Sintacticamente\n"
            " Evaluacion de Operaciones\n"
            " Grafica de  Arbol\n"
            " Exportar en HTML\n"
            " Reporte de Errores en html\n\n"
            "Creado por: Jarod y  Guillermo\n"
            "Cual quier duda o consulta enviar a correo:jmacb1234@gmail.com/n")

# ----------------------- MAIN -----------------------
if __name__ == "__main__":
    root = tk.Tk()
    app = AnalizadorGUI(root)
    root.mainloop()